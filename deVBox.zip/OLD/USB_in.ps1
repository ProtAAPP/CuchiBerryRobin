﻿
 Add-Content -Path $PSScriptRoot\output.txt -Value 'USB Flash Drive was inserted.';
