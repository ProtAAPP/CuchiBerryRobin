# CuchiBerryRobin
Your own RaspberryRobin Emulation, infect USB and get the payload from de internet.
